export class Managers {
   managerEmail: string;
   managerPassword: string;
   managerName: string;
   managerPincode: string;
}
