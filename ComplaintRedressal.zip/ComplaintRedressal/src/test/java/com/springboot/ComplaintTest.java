package com.springboot;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ComplaintTest {

	
    WebDriver driver;

    @Test (priority=0)  
  public void testingAdmin() throws InterruptedException {
      

        long start = System.currentTimeMillis();
        driver.manage().window().maximize();
        driver.get("http://localhost:4200/home");
        long finish = System.currentTimeMillis();
        long totalTime = finish - start; 
        Thread.sleep(1000);
        System.out.println("Total Time for main page load = "+(totalTime*0.001)+" Seconds"); 
        driver.navigate().to("http://localhost:4200/adminlogin");
       
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/div[1]/input")).sendKeys("admin");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/div[2]/input")).sendKeys("admin@123");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/button")).click();
        System.out.println("sucessfully signUp ");
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[1]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[2]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[3]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[4]/button")).click();
        Thread.sleep(2000);
           driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[5]/button")).click();
        Thread.sleep(2000);
        
        System.out.println("sucessfully viewed Admin page components");
              
}
    @Test (priority=1)  
    public void customerregister() throws InterruptedException {
    	

           driver.get("http://localhost:4200/customers");
           Thread.sleep(2000);
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[1]/input")).sendKeys("customer@gmail.com");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[2]/input")).sendKeys("customer@123");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[3]/input")).sendKeys("ajay");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[4]/input")).sendKeys("9874567890");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[5]/input")).sendKeys("AK colony ,Annastreet,chennai");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[6]/input")).sendKeys("623456");
          Thread.sleep(2000);
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/button[1]")).click();
          Thread.sleep(2000);
   
          Alert alert = driver.switchTo().alert();		
    		
          // Capturing alert message.    
          String alertMessage= driver.switchTo().alert().getText();		
          String regf="Phone Number Already Registered";	
          if(alertMessage.equals(regf)) {
        	  System.out.println("User Already  Registerd as Customer");
          }
          else {
          System.out.println("sucessfully Registerd as Customer");
          }
          driver.switchTo().alert().accept();
          
          Thread.sleep(3000);
       }

@Test (priority=2)  
  public void customersignin() throws InterruptedException {
      
         driver.get("http://localhost:4200/customers");
         Thread.sleep(3000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/div[1]/input")).sendKeys("customer@gmail.com");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/div[2]/input")).sendKeys("customer@123");
        Thread.sleep(3000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/button")).click();
        Thread.sleep(2000);
        try {
       Alert alert = driver.switchTo().alert();		
		
        // Capturing alert message.    
       String alertMessage= driver.switchTo().alert().getText();	
       String Loginf="Incorrect Details";
       if(alertMessage.equals(Loginf) ) {
    	   System.out.println("Incorrect Details Cannot login");
    	 
       }
       else { 	
    	   driver.switchTo().alert().accept();
           Thread.sleep(3000);


       }
       System.out.println("sucessfully logged in as customer");
      
        }
        catch(NoAlertPresentException e) {
     
        }
        
}

@Test (priority=3)
public void engineerlogin() throws InterruptedException {
    
    driver.get("http://localhost:4200/engineers");
    Thread.sleep(3000);
   driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/div[1]/input")).sendKeys("engineer@gmail.com");
   driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/div[2]/input")).sendKeys("engineer@123");
   driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/button")).click();
   Thread.sleep(3000);
   try {
   Alert al = driver.switchTo().alert();	    
  String alertMessage= driver.switchTo().alert().getText();	
  String Logf="Incorrect Details";
  if(alertMessage.equals(Logf)) {
	   System.out.println("Incorrect Details Cannot login");
	  
  }
  else {
	  driver.switchTo().alert().accept();
	  Thread.sleep(3000);
 
  }
  System.out.println("sucessfully logged in as Engineer");
  

   }
   catch(NoAlertPresentException e) {
	    
   }
   
} 

   
@Test  (priority=5)  
public void engineerregister() throws InterruptedException {
    
       driver.get("http://localhost:4200/engineers");
       Thread.sleep(2000);
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[1]/input")).sendKeys("engineer@gmail.com");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[2]/input")).sendKeys("engineer@123");
      Thread.sleep(2000);
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[3]/input")).sendKeys("engineer");
     
      Thread.sleep(2000);
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/button[1]")).click();
try {
   Alert al = driver.switchTo().alert();	    
  String aMessage= driver.switchTo().alert().getText();	
 System.out.println(aMessage);
	   System.out.println("sucessfully Registerd as Engineers");
	   driver.switchTo().alert().accept();
	   Thread.sleep(3000);
  
  
 
   }
   catch(NoAlertPresentException e) {

   }     
      Thread.sleep(2000);
      
   }



@Test (priority=4)  
public void managerlogin() throws InterruptedException {
    
     
          driver.get("http://localhost:4200/managers");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/div[1]/input")).sendKeys("manager@gmail.com");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/div[2]/input")).sendKeys("manager@123");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/button")).click();
         Thread.sleep(1000);
       try {
   Alert al = driver.switchTo().alert();	    
  String alertMessage= driver.switchTo().alert().getText();	
  String Logf="Incorrect Details";

  if(alertMessage.equals(Logf)) {
	   System.out.println("Incorrect Details Cannot login");
	   
	    Thread.sleep(2000);
  }
  else {
	
		  System.out.println("sucessfully logged in as Manager");

		   
       }
  driver.switchTo().alert().accept();
  Thread.sleep(2000);
  
       }
  catch(NoAlertPresentException e) {
	  
  }
         
}
  

    @BeforeMethod 
    
   	public void beforeClass() {
   		System.setProperty("webdriver.chrome.driver",
   				"C:\\Users\\naren\\OneDrive\\Desktop\\RLL Project\\chromedriver.exe");
   		driver = new ChromeDriver();
   		driver.get("http://localhost:4200/home");
   		driver.manage().window().maximize();
   	}

   	@AfterMethod
   	public void afterClass() {
   		driver = null;
   	}
}
